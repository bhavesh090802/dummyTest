"""
Comprehensive unit test suite for AI-Driven JUnit Test Generator modules.
"""

import os
import sys
import tempfile
import unittest
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from config import GeneratorConfig, DEFAULT_TARGET_COVERAGE
from core.git_handler import GitHandler
from core.maven_runner import MavenRunner
from core.llm_client import LLMClient
from core.test_generator import TestGeneratorOrchestrator


class TestGitHandler(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.p_path = Path(self.temp_dir.name)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_repo_detection(self):
        handler = GitHandler(str(self.p_path))
        self.assertFalse(handler.is_git_repository())

        # Create dummy .git directory
        (self.p_path / ".git").mkdir()
        self.assertTrue(handler.is_git_repository())

    def test_verify_source_integrity(self):
        (self.p_path / ".git").mkdir()
        handler = GitHandler(str(self.p_path))
        # Since git status may fail on empty fake git dir, test method returns cleanly
        is_clean, msg = handler.verify_source_integrity(baseline_status="")
        self.assertTrue(is_clean or "src/main" in msg)


class TestMavenRunner(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.p_path = Path(self.temp_dir.name)
        self.runner = MavenRunner(str(self.p_path))

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_has_pom(self):
        self.assertFalse(self.runner.has_pom())
        (self.p_path / "pom.xml").write_text("<project></project>", encoding="utf-8")
        self.assertTrue(self.runner.has_pom())

    def test_parse_jacoco_xml(self):
        jacoco_dir = self.p_path / "target" / "site" / "jacoco"
        jacoco_dir.mkdir(parents=True)
        xml_content = """<?xml version="1.0" encoding="UTF-8"?>
<report name="test-report">
    <counter type="INSTRUCTION" missed="20" covered="80"/>
    <counter type="BRANCH" missed="5" covered="15"/>
    <counter type="LINE" missed="10" covered="90"/>
    <counter type="METHOD" missed="2" covered="18"/>
    <counter type="CLASS" missed="0" covered="5"/>
</report>
"""
        (jacoco_dir / "jacoco.xml").write_text(xml_content, encoding="utf-8")
        metrics = self.runner.parse_jacoco_report()

        self.assertIsNotNone(metrics)
        self.assertEqual(metrics["line_coverage"], 90.0)
        self.assertEqual(metrics["branch_coverage"], 75.0)
        self.assertEqual(metrics["instruction_coverage"], 80.0)
        self.assertEqual(metrics["covered_lines"], 90)
        self.assertEqual(metrics["missed_lines"], 10)
        self.assertEqual(metrics["total_lines"], 100)

    def test_extract_error_summary(self):
        sample_output = """
[INFO] Scanning for projects...
[INFO] -------------------------------------------------------------
[ERROR] COMPILATION ERROR : 
[INFO] -------------------------------------------------------------
[ERROR] /com/example/UserServiceTest.java:[24,15] cannot find symbol
  symbol:   method invalidMethod()
  location: class com.example.UserService
[INFO] 1 error
[INFO] -------------------------------------------------------------
[ERROR] Failed to execute goal org.apache.maven.plugins:maven-compiler-plugin:3.11.0:testCompile
"""
        summary = self.runner.extract_error_summary(sample_output)
        self.assertIn("cannot find symbol", summary)
        self.assertIn("UserServiceTest.java", summary)


class TestLLMClient(unittest.TestCase):
    def setUp(self):
        self.config = GeneratorConfig(llm_provider="dry_run")
        self.client = LLMClient(self.config)

    def test_load_skill_file(self):
        content = self.client._load_skill_file()
        self.assertIn("JUnit", content)
        self.assertIn("Strict Guardrails", content)

    def test_clean_java_code(self):
        raw = """Here is your JUnit 5 test class:
```java
package com.example;

import org.junit.jupiter.api.Test;

class UserServiceTest {
    @Test
    void test() {}
}
```
Hope this helps!"""
        cleaned = self.client._clean_java_code(raw)
        self.assertTrue(cleaned.startswith("package com.example;"))
        self.assertTrue(cleaned.endswith("}"))
        self.assertNotIn("Here is your", cleaned)

    def test_mock_test_generation(self):
        sample_java = """package com.example.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {
    public User getUserById(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("ID cannot be null");
        }
        return new User(id, "Alice");
    }

    public boolean deleteUser(Long id) {
        return true;
    }
}
"""
        code = self.client.generate_junit_test(
            source_code=sample_java,
            class_name="UserService",
            package_name="com.example.service",
        )
        self.assertIn("package com.example.service;", code)
        self.assertIn("class UserServiceTest", code)
        self.assertIn("@Test", code)
        self.assertIn("getUserById", code)
        self.assertIn("deleteUser", code)


class TestOrchestratorGuardrails(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.p_path = Path(self.temp_dir.name)
        # Create minimal valid structure
        (self.p_path / "pom.xml").write_text("<project></project>", encoding="utf-8")
        (self.p_path / ".git").mkdir()
        (self.p_path / "src" / "main" / "java" / "com" / "demo").mkdir(parents=True)
        (self.p_path / "src" / "test" / "java" / "com" / "demo").mkdir(parents=True)

        self.java_file = self.p_path / "src" / "main" / "java" / "com" / "demo" / "Calculator.java"
        self.java_file.write_text("""package com.demo;
public class Calculator {
    public int add(int a, int b) { return a + b; }
}
""", encoding="utf-8")

        self.config = GeneratorConfig(
            project_path=str(self.p_path),
            llm_provider="dry_run",
        )
        self.orch = TestGeneratorOrchestrator(self.config)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_strict_guardrail_prevents_writing_to_src_main(self):
        # Attempting to write to src/main must raise PermissionError
        forbidden_path = self.p_path / "src" / "main" / "java" / "com" / "demo" / "Calculator.java"
        with self.assertRaises(PermissionError):
            self.orch._assert_safe_write_path(forbidden_path)

    def test_strict_guardrail_allows_writing_to_src_test(self):
        allowed_path = self.p_path / "src" / "test" / "java" / "com" / "demo" / "CalculatorTest.java"
        # Should not raise exception
        try:
            self.orch._assert_safe_write_path(allowed_path)
        except PermissionError:
            self.fail("Safe write path in src/test/java was wrongly rejected.")

    def test_discover_all_source_classes(self):
        classes = self.orch.discover_all_source_classes()
        self.assertEqual(len(classes), 1)
        self.assertEqual(classes[0]["class_name"], "Calculator")
        self.assertEqual(classes[0]["package_name"], "com.demo")


if __name__ == "__main__":
    unittest.main()
