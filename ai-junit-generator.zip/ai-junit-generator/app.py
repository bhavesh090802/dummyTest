"""
Streamlit Application Entrypoint for AI-Driven Automated JUnit Test Generator.
"""

import os
import sys
from pathlib import Path
import streamlit as st

# Ensure project root is in sys.path
APP_DIR = Path(__file__).resolve().parent
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from config import (
    DEFAULT_TARGET_COVERAGE,
    DEFAULT_MAX_REPAIR_RETRIES,
    SUPPORTED_PROVIDERS,
    GeneratorConfig,
    TOOL_ROOT,
)
from core.git_handler import GitHandler
from core.maven_runner import MavenRunner
from core.test_generator import TestGeneratorOrchestrator


st.set_page_config(
    page_title="AI JUnit Test Generator",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Load custom CSS
css_path = APP_DIR / "templates" / "style.css"
if css_path.is_file():
    st.markdown(f"<style>{css_path.read_text(encoding='utf-8')}</style>", unsafe_allow_html=True)

# Initialize Session State
if "baseline_coverage" not in st.session_state:
    st.session_state.baseline_coverage = None
if "final_coverage" not in st.session_state:
    st.session_state.final_coverage = None
if "run_summary" not in st.session_state:
    st.session_state.run_summary = None
if "logs" not in st.session_state:
    st.session_state.logs = []


def add_log(msg: str):
    st.session_state.logs.append(msg)


# --- SIDEBAR CONFIGURATION ---
with st.sidebar:
    st.markdown("### ⚙️ Engine Settings")
    st.caption("AI-Driven Automated JUnit Test Generator v1.0")

    # Target Project Path
    st.subheader("1. Project Path")
    project_path_input = st.text_input(
        "Local Java Project Root",
        value=st.session_state.get("project_path", ""),
        placeholder="e.g. C:/Users/name/Projects/SpringBoot/my-service",
        help="Absolute path to Java project containing pom.xml and .git folder.",
    )
    st.session_state.project_path = project_path_input.strip()

    # Path Validation Indicator
    project_valid = False
    validation_error = ""
    if project_path_input.strip():
        p = Path(project_path_input.strip())
        if not p.exists():
            validation_error = "Directory does not exist."
        elif not (p / "pom.xml").is_file():
            validation_error = "Missing pom.xml at project root."
        else:
            git_handler = GitHandler(str(p))
            if not git_handler.is_git_repository():
                validation_error = "Missing .git repository in project root."
            else:
                project_valid = True

    if project_valid:
        st.success("✅ Valid Java Maven & Git Repository", icon="✅")
    elif project_path_input.strip():
        st.error(f"❌ {validation_error}", icon="🚨")

    st.markdown("---")

    # LLM Settings
    st.subheader("2. AI Model & Provider")
    provider_key = st.selectbox(
        "Provider",
        options=list(SUPPORTED_PROVIDERS.keys()),
        format_func=lambda k: SUPPORTED_PROVIDERS[k]["name"],
        index=0,
    )

    prov_meta = SUPPORTED_PROVIDERS[provider_key]
    model_options = prov_meta.get("models", [])
    default_model = prov_meta.get("default_model", "")

    selected_model = st.selectbox(
        "Model",
        options=model_options,
        index=model_options.index(default_model) if default_model in model_options else 0,
    )

    api_key_input = ""
    if provider_key not in ("ollama", "dry_run"):
        env_var = prov_meta.get("env_var", "")
        env_val = os.getenv(env_var, "")
        api_key_input = st.text_input(
            f"API Key ({env_var})" if env_var else "API Key",
            type="password",
            value=env_val,
            help=f"Loaded from {env_var} if set in environment.",
        )

    custom_endpoint = ""
    if provider_key in ("ollama", "openai_compatible"):
        default_ep = prov_meta.get("api_base", "")
        custom_endpoint = st.text_input("Endpoint URL", value=default_ep)

    st.markdown("---")

    # Advanced Settings
    with st.expander("🛠️ Advanced Settings", expanded=False):
        max_retries = st.number_input("Max Auto-Repair Retries", min_value=1, max_value=5, value=DEFAULT_MAX_REPAIR_RETRIES)
        maven_timeout = st.number_input("Maven Timeout (sec)", min_value=60, max_value=600, value=240, step=30)
        base_branch = st.text_input("Base Git Branch for Diff Mode", value="main", help="Branch to compare against (e.g. main or master).")


# --- MAIN CONTENT AREA ---
st.markdown("<div class='main-title'>AI-Driven Automated JUnit Test Generator</div>", unsafe_allow_html=True)
st.markdown(
    "<div class='subtitle'>Autonomous, zero-source-modification test generation with SKILL.md intelligence and live JaCoCo coverage metrics.</div>",
    unsafe_allow_html=True,
)

# Guardrail badge
st.markdown(
    "<div class='guardrail-badge'>🛡️ Strict Guardrail Active: Zero source code modification (src/main/ protected)</div>",
    unsafe_allow_html=True,
)

# --- DASHBOARD METRICS DISPLAY ---
st.markdown("### 📊 Code Coverage Dashboard")

col_curr, col_target, col_final = st.columns(3)

# 1. Current Coverage ($C_{current}$)
with col_curr:
    c_curr_val = st.session_state.baseline_coverage
    val_str = f"{c_curr_val:.1f}%" if c_curr_val is not None else "—"
    st.markdown(
        f"""
        <div class='metric-container'>
            <div class='metric-label'>Current Code Coverage (C_current)</div>
            <div class='metric-value'>{val_str}</div>
            <div class='metric-delta delta-neutral'>Baseline before test generation</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

# 2. Target Coverage ($C_{target}$)
with col_target:
    target_coverage = st.number_input(
        "Target Code Coverage (C_target)",
        min_value=50.0,
        max_value=100.0,
        value=DEFAULT_TARGET_COVERAGE,
        step=5.0,
        format="%.1f",
        help="Target coverage percentage to achieve or exceed (defaults to 90%).",
    )
    st.markdown(
        f"""
        <div class='metric-container' style='margin-top: -15px;'>
            <div class='metric-label'>Target Goal (C_target)</div>
            <div class='metric-value'>{target_coverage:.1f}%</div>
            <div class='metric-delta delta-neutral'>Configurable standard threshold</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

# 3. Post-Tool Coverage ($C_{final}$)
with col_final:
    c_final_val = st.session_state.final_coverage
    if c_final_val is not None:
        final_str = f"{c_final_val:.1f}%"
        delta = c_final_val - (c_curr_val or 0.0)
        delta_str = f"+{delta:.1f}% increase" if delta >= 0 else f"{delta:.1f}%"
        delta_class = "delta-positive" if c_final_val >= target_coverage else "delta-neutral"
    else:
        final_str = "—"
        delta_str = "Awaiting verification run"
        delta_class = "delta-neutral"

    st.markdown(
        f"""
        <div class='metric-container'>
            <div class='metric-label'>Post-Tool Coverage (C_final)</div>
            <div class='metric-value'>{final_str}</div>
            <div class='metric-delta {delta_class}'>{delta_str}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

st.markdown("<br>", unsafe_allow_html=True)

# --- EXECUTION MODE TOGGLE & SCOPE ---
st.markdown("### 🎯 Scope Identification & Mode Toggle")

col_mode, col_actions = st.columns([2, 1])

with col_mode:
    mode_selection = st.radio(
        "Select Execution Scope",
        options=["Full Codebase Mode", "Developer Changes Mode"],
        horizontal=True,
        help="Full Codebase scans all Java classes in src/main/java. Developer Changes scans uncommitted git diffs and branch commits.",
    )
    mode_key = "full" if "Full Codebase" in mode_selection else "changes"

# Target classes preview if project is valid
if project_valid:
    git_h = GitHandler(project_path_input.strip())
    if mode_key == "changes":
        detected_changes = git_h.get_developer_changes(base_branch=base_branch)
        with st.expander(f"🔍 Changed Classes in Scope ({len(detected_changes)} detected)", expanded=True):
            if detected_changes:
                for item in detected_changes:
                    st.markdown(f"**`{item['class_name']}`** — `{item['rel_path']}` `[{item['change_type']}]`")
                    if item.get("diff"):
                        with st.expander(f"View Git Diff for {item['file_name']}", expanded=False):
                            st.code(item["diff"], language="diff")
            else:
                st.info("No uncommitted or branch-committed changes detected in `src/main/java/`. If you run in this mode, it will fall back to full codebase or check uncommitted changes.")
    else:
        orch_preview = TestGeneratorOrchestrator(GeneratorConfig(project_path=project_path_input.strip()))
        classes_preview = orch_preview.discover_all_source_classes()
        with st.expander(f"📂 Full Codebase Target Classes ({len(classes_preview)} detected)", expanded=False):
            if classes_preview:
                cols = st.columns(3)
                for i, c in enumerate(classes_preview):
                    cols[i % 3].markdown(f"• **`{c['class_name']}`** (`{c['package_name']}`)")
            else:
                st.warning("No concrete Java classes found in src/main/java/.")

# Action buttons
col_btn1, col_btn2 = st.columns(2)
with col_btn1:
    btn_check_baseline = st.button("📈 Run Baseline Coverage Check Only", use_container_width=True, disabled=not project_valid)
with col_btn2:
    btn_generate = st.button("🚀 Generate JUnit Tests & Verify", type="primary", use_container_width=True, disabled=not project_valid)

# Progress bar and status placeholders
progress_bar = st.empty()
status_alert = st.empty()
console_placeholder = st.empty()


def render_logs(logs):
    formatted = "\n".join(logs[-15:])
    console_placeholder.markdown(f"<div class='terminal-console'>{formatted}</div>", unsafe_allow_html=True)


# --- EXECUTION: BASELINE COVERAGE ONLY ---
if btn_check_baseline:
    st.session_state.logs = []
    add_log(f"> Initializing baseline JaCoCo coverage calculation for {project_path_input}...")
    render_logs(st.session_state.logs)

    with st.spinner("Executing Maven with JaCoCo plugin..."):
        m_runner = MavenRunner(project_path_input, timeout_sec=int(maven_timeout))
        retcode, out, metrics = m_runner.run_baseline_coverage()
        if metrics:
            cov = metrics.get("line_coverage", 0.0)
            st.session_state.baseline_coverage = cov
            add_log(f"> [SUCCESS] Baseline line coverage calculated: {cov:.1f}%")
            add_log(f"> Branch coverage: {metrics.get('branch_coverage', 0.0):.1f}% | Instructions: {metrics.get('instruction_coverage', 0.0):.1f}%")
            st.success(f"Baseline coverage successfully assessed: **{cov:.1f}%**")
        else:
            add_log("> [WARNING] Could not parse jacoco.xml. Maven test output:")
            add_log(m_runner.extract_error_summary(out))
            st.warning("JaCoCo report could not be generated. Check if Maven tests compile.")
        render_logs(st.session_state.logs)
    st.rerun()


# --- EXECUTION: GENERATE JUNIT TESTS & REPAIR ---
if btn_generate:
    st.session_state.logs = []
    st.session_state.run_summary = None
    add_log(f"> [INIT] Starting AI-Driven JUnit Test Generation Pipeline...")
    add_log(f"> Target Project: {project_path_input}")
    add_log(f"> Execution Mode: {mode_selection}")
    add_log(f"> AI Provider: {SUPPORTED_PROVIDERS[provider_key]['name']} ({selected_model})")
    render_logs(st.session_state.logs)

    config = GeneratorConfig(
        project_path=project_path_input,
        mode=mode_key,
        target_coverage=float(target_coverage),
        max_retries=int(max_retries),
        base_branch=base_branch,
        llm_provider=provider_key,
        llm_model=selected_model,
        api_key=api_key_input,
        custom_endpoint=custom_endpoint,
        maven_timeout=int(maven_timeout),
    )

    orchestrator = TestGeneratorOrchestrator(config)
    pipeline = orchestrator.run_generation_pipeline()

    final_result = None
    try:
        for event in pipeline:
            prog = event.get("progress", 0.0)
            msg = event.get("message", "")
            stage = event.get("stage", "")
            status = event.get("status", "info")

            progress_bar.progress(min(1.0, max(0.0, prog)))

            if status == "error":
                status_alert.error(msg)
                add_log(f"> [ERROR] {msg}")
            elif status == "warning":
                status_alert.warning(msg)
                add_log(f"> [WARN] {msg}")
            elif status == "success":
                status_alert.success(msg)
                add_log(f"> [SUCCESS] {msg}")
            else:
                status_alert.info(msg)
                add_log(f"> [INFO] {msg}")

            if "error_summary" in event:
                add_log(f"--- Compiler/Test Failure Log ---\n{event['error_summary']}\n---------------------------------")

            render_logs(st.session_state.logs)

            if stage == "baseline_coverage" and "data" in event:
                st.session_state.baseline_coverage = event["data"].get("current_coverage", 0.0)

            if stage == "complete":
                final_result = event.get("data")
                if final_result:
                    st.session_state.run_summary = final_result
                    st.session_state.final_coverage = final_result.get("final_coverage", 0.0)

    except Exception as e:
        status_alert.error(f"Pipeline encountered unhandled exception: {str(e)}")
        add_log(f"> [FATAL] {str(e)}")
        render_logs(st.session_state.logs)

    st.rerun()


# --- RESULTS & POST-RUN DASHBOARD ---
if st.session_state.run_summary:
    summary = st.session_state.run_summary
    st.markdown("---")
    st.markdown("### 📋 Generation & Verification Report")

    # Guardrail Verification Banner
    st.success(f"🛡️ **Source Code Integrity:** {summary.get('source_integrity', 'Verified Clean')}")

    # Results tabs
    tab_tests, tab_metrics, tab_repair = st.tabs(["📝 Generated Test Cases", "📊 JaCoCo Detailed Metrics", "🔧 Auto-Repair Log"])

    with tab_tests:
        generated_classes = summary.get("generated_classes", [])
        if generated_classes:
            st.markdown(f"**Successfully processed {len(generated_classes)} test class(es):**")
            for item in generated_classes:
                pass_icon = "✅ Passed" if item.get("passed") else "⚠️ Needs Review"
                retries_info = f"({item.get('repair_attempts', 0)} repair cycle(s))" if item.get('repair_attempts', 0) > 0 else "(First attempt passed)"
                with st.expander(f"`{item['class_name']}Test.java` — {pass_icon} {retries_info}", expanded=True):
                    st.caption(f"Saved to: `{item['test_file']}`")
                    st.code(item.get("code", ""), language="java")
        else:
            st.info("No test classes generated in this run.")

    with tab_metrics:
        cov_metrics = summary.get("coverage_metrics", {})
        m_col1, m_col2, m_col3 = st.columns(3)
        m_col1.metric("Line Coverage", f"{cov_metrics.get('line_coverage', 0.0):.1f}%", 
                      delta=f"{(cov_metrics.get('line_coverage', 0.0) - (summary.get('current_coverage') or 0.0)):.1f}%")
        m_col2.metric("Branch Coverage", f"{cov_metrics.get('branch_coverage', 0.0):.1f}%")
        m_col3.metric("Instruction Coverage", f"{cov_metrics.get('instruction_coverage', 0.0):.1f}%")

        st.json({
            "Covered Lines": cov_metrics.get("covered_lines", 0),
            "Missed Lines": cov_metrics.get("missed_lines", 0),
            "Total Lines": cov_metrics.get("total_lines", 0),
            "Covered Branches": cov_metrics.get("covered_branches", 0),
            "Missed Branches": cov_metrics.get("missed_branches", 0),
            "Target Coverage": f"{summary.get('target_coverage', 90.0):.1f}%",
            "Build Exit Code": summary.get("build_exit_code", 0),
        })

    with tab_repair:
        classes_with_repairs = [c for c in summary.get("generated_classes", []) if c.get("repair_attempts", 0) > 0]
        if classes_with_repairs:
            for c in classes_with_repairs:
                st.markdown(f"**Class:** `{c['class_name']}Test` — **Repair attempts:** {c['repair_attempts']}")
        else:
            st.success("🎉 All generated tests compiled and passed without requiring repair retries!")
