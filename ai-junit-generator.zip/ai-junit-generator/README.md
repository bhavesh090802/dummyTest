# AI-Driven Automated JUnit Test Generator ⚡

An autonomous, standalone Python-based desktop and web UI application that scans local Java / Spring Boot projects, analyzes target classes using AI guidelines specified in `SKILL.md`, and generates robust, compilable JUnit 5 test cases.

It provides real-time JaCoCo code coverage metrics (**Current vs Target vs Post-Generation**), supports **Full Codebase** and **Developer Changes (Git diff)** modes, features an automatic **Maven Verification & Auto-Repair Loop**, and strictly enforces **Zero Source Code Modification** under `src/main/`.

---

## 🚀 Key Features

* **Strict Guardrails (Zero Source Modification):**
  * Guarantees that no file in `src/main/` or `pom.xml` is ever modified, reformatted, or deleted.
  * Writes strictly and exclusively into `src/test/java/`.
  * Verifies git integrity before and after test generation.

* **Dual Execution Modes:**
  * **Full Codebase Mode:** Recursively scans and generates JUnit 5 tests for all concrete Java classes under `src/main/java/`.
  * **Developer Changes Mode:** Queries Git to pinpoint modified or added `.java` files from uncommitted working tree changes (`git status`, `git diff`) and committed branch changes relative to a base branch (`main`/`master`).

* **Live JaCoCo Coverage Dashboard:**
  * Displays **Current Coverage ($C_{\text{current}}$)**, **Target Coverage ($C_{\text{target}}$ - Default 90%)**, and **Post-Tool Coverage ($C_{\text{final}}$)**.
  * Breaks down line, branch, and instruction coverage.
  * Automatically invokes JaCoCo on-the-fly (`org.jacoco:jacoco-maven-plugin:0.8.11`) without modifying the project's `pom.xml`.

* **Autonomous AI Auto-Repair Loop:**
  * Executes Maven (`mvn test -Dtest={ClassName}Test` / `mvn clean test`).
  * If compilation or assertion errors occur, captures stack traces and feeds them back to the LLM to repair and re-generate the test class (up to 3 retry attempts).

* **Multi-Provider AI Engine:**
  * Google Gemini (`gemini-2.5-flash`, `gemini-2.5-pro`, `gemini-1.5-pro`)
  * OpenAI (`gpt-4o`, `gpt-4o-mini`, `o3-mini`)
  * Anthropic Claude (`claude-3-7-sonnet`, `claude-3-5-sonnet`)
  * Ollama (Local LLMs: `qwen2.5-coder`, `llama3.1`, `codellama`)
  * OpenAI-Compatible Endpoints (Groq, OpenRouter, DeepSeek, vLLM)
  * Offline Mock / Dry-Run Generator (instantly generates JUnit 5 tests without an API key)

---

## 📁 Project Directory Layout

```text
ai-junit-generator/
├── app.py                     # Streamlit UI Application entrypoint
├── config.py                  # Configuration & default settings
├── SKILL.md                   # Core AI prompt & guardrail specifications
├── requirements.txt           # Python dependencies
├── core/
│   ├── __init__.py
│   ├── git_handler.py         # Git diff and uncommitted file detection
│   ├── maven_runner.py        # Executing Maven builds and parsing JaCoCo XML reports
│   ├── llm_client.py          # AI interaction module (injecting SKILL.md rules)
│   └── test_generator.py      # Orchestrator & auto-repair loop
├── templates/
│   └── style.css              # Custom modern styling
└── tests/                     # Test suite for the generator itself
```

---

## 🛠️ Installation & Quickstart

### Prerequisites
* **Python:** 3.10+ (tested on Python 3.14)
* **Java Development Kit (JDK):** 17+
* **Apache Maven:** 3.8+
* **Git:** 2.x+

### 1. Install Dependencies
```bash
cd C:\Users\bhave\Projects\ai-junit-generator
python -m pip install -r requirements.txt
```

### 2. Launch the Application
```bash
python -m streamlit run app.py
```
The browser interface will open automatically at `http://localhost:8501`.

---

## 📖 How to Use

1. **Specify Project Path:** In the left sidebar, enter the absolute path to your local Java Spring Boot project containing `pom.xml` and `.git` (e.g. `C:\Users\bhave\Projects\SpringBoot\journalApp`).
2. **Select AI Provider & Model:** Choose your preferred AI provider (e.g. Gemini, OpenAI, or Offline Mock) and supply your API key (or set `GEMINI_API_KEY` / `OPENAI_API_KEY` in environment).
3. **Choose Execution Mode:**
   * **Full Codebase Mode** to generate tests for all classes.
   * **Developer Changes Mode** to focus strictly on uncommitted/branch-changed classes.
4. **Set Target Coverage:** Adjust the target coverage slider (defaults to `90.0%`).
5. **Run Baseline or Full Generation:**
   * Click **"Run Baseline Coverage Check Only"** to compute current JaCoCo metrics.
   * Click **"Generate JUnit Tests & Verify"** to run the complete autonomous test generation, Maven verification, and auto-repair cycle.
6. **Review Results:** Inspect the generated test classes in the viewer, verify detailed JaCoCo coverage metrics, review the auto-repair log, and confirm source code integrity.
