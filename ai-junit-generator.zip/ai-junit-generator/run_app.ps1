# PowerShell launcher for AI-Driven Automated JUnit Test Generator
Set-Location -Path $PSScriptRoot
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  Launching AI-Driven Automated JUnit Test Generator... " -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Cyan
python -m streamlit run app.py
