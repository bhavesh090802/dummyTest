@echo off
title AI-Driven Automated JUnit Test Generator
cd /d "%~dp0"
echo ========================================================
echo   Launching AI-Driven Automated JUnit Test Generator...
echo ========================================================
python -m streamlit run app.py
pause
