# JUnit Test Case Generation Skill Guidelines

## Objective
Generate complete, robust, maintainable JUnit 5 test cases for Java/Spring Boot applications to achieve or exceed the target code coverage (default 90%).

## Strict Guardrails
1. DO NOT modify any application code under `src/main/`.
2. ONLY generate or edit test classes inside `src/test/java/`.
3. Generated tests MUST compile and pass cleanly via `mvn clean test`.
4. Output ONLY valid, compilable Java code. Never output incomplete code or comments like `// TODO: implement`.

## Technical Conventions
- **Frameworks & Annotations:**
  - JUnit 5 (`org.junit.jupiter.api.Test`, `org.junit.jupiter.api.BeforeEach`, `@DisplayName`, `@ParameterizedTest`, `@ValueSource`).
  - Mockito 4/5 (`org.mockito.Mock`, `org.mockito.InjectMocks`, `org.mockito.junit.jupiter.MockitoExtension`, `org.mockito.Mockito.*`).
  - Assertions: Standard JUnit Jupiter assertions (`assertEquals`, `assertTrue`, `assertThrows`, `assertNotNull`, `assertAll`) or AssertJ (`assertThat`) if available.
- **Structure:**
  - Follow the standard Arrange-Act-Assert (AAA) pattern clearly separated in each test method.
  - Name test methods descriptively: `givenCondition_whenAction_thenExpectedResult()` or using `@DisplayName`.
- **Coverage Target:**
  - Focus heavily on boundary conditions, edge cases, empty/null values, exception paths, and all conditional branches (`if/else`, ternary operators, `switch`).
  - Test happy path, negative path, and boundary conditions for every public method.
  - Test thrown exceptions with `assertThrows(ExpectedException.class, () -> service.method())`.
- **Spring Boot & Mocking Strategy:**
  - Prefer fast, pure unit tests with Mockito (`@ExtendWith(MockitoExtension.class)`) for Service, Utility, and Domain logic.
  - For Spring Controllers: Use `@WebMvcTest(TargetController.class)` with `@MockBean` / `MockMvc` or pure standalone `MockMvcBuilders.standaloneSetup(controller)` to ensure fast execution.
  - For Repositories: Use `@DataJpaTest` or unit-test queries where applicable.
  - Avoid heavy `@SpringBootTest` unless full context loading is strictly necessary, to keep build times ultra-fast.
- **Package & File Naming:**
  - Test class must mirror the exact package of the target class.
  - Test class name must be `{ClassName}Test`.
  - Stored inside `src/test/java/{package-path}/{ClassName}Test.java`.

## Execution Scope Instructions
- **Full Mode:** Process all eligible concrete classes in `src/main/java/`.
- **Developer Changes Mode:** Focus strictly on target classes matching git diffs (uncommitted or committed vs base branch). Ensure modified or newly added methods in those target classes have comprehensive, focused test coverage.

## Auto-Repair Protocol
When fixing a compilation or test failure:
1. Carefully inspect the compiler error message, missing imports, mismatched types, or assertion failure.
2. Ensure all required imports (`org.junit.jupiter.api.*`, `org.mockito.*`, target package classes) are present.
3. Check for package declaration matching the directory structure.
4. Correct mocked method return types and argument matchers (`any()`, `eq()`, `isNull()`).
5. Ensure tests are fully deterministic with zero external network or database dependencies unless an in-memory database (H2) is configured.
