"""
Maven build runner and JaCoCo coverage report parser.
Handles:
- Discovering Maven / Maven wrapper
- Running test & JaCoCo goals
- Parsing XML and HTML JaCoCo coverage reports (Line, Branch, Instruction)
- Extracting build failure stack traces and compilation errors for AI auto-repair
"""

import os
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List


class MavenRunner:
    def __init__(self, project_dir: str, timeout_sec: int = 240):
        self.project_dir = Path(project_dir).resolve()
        self.timeout_sec = timeout_sec
        self.mvn_cmd = self._find_maven_executable()

    def _find_maven_executable(self) -> str:
        """Finds mvnw.cmd / mvnw in project or system mvn / mvn.cmd."""
        # 1. Project-level wrapper
        if os.name == "nt":
            mvnw_win = self.project_dir / "mvnw.cmd"
            if mvnw_win.is_file():
                return str(mvnw_win)
        mvnw = self.project_dir / "mvnw"
        if mvnw.is_file() and os.access(str(mvnw), os.X_OK):
            return str(mvnw)

        # 2. System maven
        system_mvn = shutil.which("mvn.cmd" if os.name == "nt" else "mvn")
        if system_mvn:
            return system_mvn
        
        # Fallback to plain string
        return "mvn.cmd" if os.name == "nt" else "mvn"

    def has_pom(self) -> bool:
        """Checks if pom.xml exists in the project root."""
        return (self.project_dir / "pom.xml").is_file()

    def run_command(self, args: List[str], env: Optional[Dict[str, str]] = None) -> Tuple[int, str, str]:
        """
        Executes a Maven command.
        Returns (returncode, stdout, stderr).
        """
        cmd = [self.mvn_cmd] + args
        merged_env = os.environ.copy()
        if env:
            merged_env.update(env)

        try:
            proc = subprocess.run(
                cmd,
                cwd=str(self.project_dir),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=self.timeout_sec,
                shell=(os.name == "nt" and not self.mvn_cmd.endswith(".exe")),
            )
            return proc.returncode, proc.stdout, proc.stderr
        except subprocess.TimeoutExpired as te:
            stdout = te.stdout or "" if isinstance(te.stdout, str) else ""
            stderr = te.stderr or "" if isinstance(te.stderr, str) else ""
            return -1, stdout + f"\n[ERROR] Maven process timed out after {self.timeout_sec} seconds.", stderr
        except Exception as e:
            return -2, f"[ERROR] Failed to execute Maven: {str(e)}", ""

    def run_baseline_coverage(self, jacoco_version: str = "0.8.11") -> Tuple[int, str, Optional[Dict[str, float]]]:
        """
        Executes Maven test with JaCoCo plugin to determine baseline coverage.
        Direct plugin invocation ensures zero pom.xml modification!
        """
        prepare_goal = f"org.jacoco:jacoco-maven-plugin:{jacoco_version}:prepare-agent"
        report_goal = f"org.jacoco:jacoco-maven-plugin:{jacoco_version}:report"
        
        # We allow tests to fail without crashing baseline collection if there are existing faulty tests
        args = [prepare_goal, "test", report_goal, "-Dmaven.test.failure.ignore=true"]
        retcode, stdout, stderr = self.run_command(args)
        
        coverage = self.parse_jacoco_report()
        output = stdout + ("\n" + stderr if stderr else "")
        return retcode, output, coverage

    def run_clean_test(self, with_jacoco: bool = True, jacoco_version: str = "0.8.11") -> Tuple[int, str, Optional[Dict[str, float]]]:
        """
        Runs `mvn clean test` (and optionally JaCoCo report).
        Returns (returncode, full_output, coverage_metrics).
        """
        if with_jacoco:
            prepare_goal = f"org.jacoco:jacoco-maven-plugin:{jacoco_version}:prepare-agent"
            report_goal = f"org.jacoco:jacoco-maven-plugin:{jacoco_version}:report"
            args = ["clean", prepare_goal, "test", report_goal]
        else:
            args = ["clean", "test"]

        retcode, stdout, stderr = self.run_command(args)
        output = stdout + ("\n" + stderr if stderr else "")
        coverage = self.parse_jacoco_report() if with_jacoco else None
        return retcode, output, coverage

    def run_single_test_class(self, test_class_name: str) -> Tuple[int, str]:
        """
        Runs only a specific test class for fast verification during auto-repair.
        e.g. mvn test -Dtest=UserServiceTest
        """
        args = ["test", f"-Dtest={test_class_name}"]
        retcode, stdout, stderr = self.run_command(args)
        output = stdout + ("\n" + stderr if stderr else "")
        return retcode, output

    def parse_jacoco_report(self) -> Optional[Dict[str, float]]:
        """
        Parses target/site/jacoco/jacoco.xml to extract coverage metrics.
        Returns dictionary with:
        - line_coverage
        - branch_coverage
        - instruction_coverage
        - method_coverage
        - class_coverage
        - total_lines, covered_lines, missed_lines
        """
        jacoco_xml = self.project_dir / "target" / "site" / "jacoco" / "jacoco.xml"
        if not jacoco_xml.is_file():
            # Try HTML fallback
            return self._parse_jacoco_html()

        try:
            tree = ET.parse(str(jacoco_xml))
            root = tree.getroot()

            metrics: Dict[str, Any] = {
                "line_coverage": 0.0,
                "branch_coverage": 0.0,
                "instruction_coverage": 0.0,
                "method_coverage": 0.0,
                "class_coverage": 0.0,
                "covered_lines": 0,
                "missed_lines": 0,
                "total_lines": 0,
                "covered_branches": 0,
                "missed_branches": 0,
                "total_branches": 0,
            }

            # Top-level counters under <report>
            for counter in root.findall("counter"):
                c_type = counter.attrib.get("type", "")
                missed = int(counter.attrib.get("missed", 0))
                covered = int(counter.attrib.get("covered", 0))
                total = missed + covered
                pct = (covered / total * 100.0) if total > 0 else 0.0

                if c_type == "LINE":
                    metrics["line_coverage"] = round(pct, 2)
                    metrics["covered_lines"] = covered
                    metrics["missed_lines"] = missed
                    metrics["total_lines"] = total
                elif c_type == "BRANCH":
                    metrics["branch_coverage"] = round(pct, 2)
                    metrics["covered_branches"] = covered
                    metrics["missed_branches"] = missed
                    metrics["total_branches"] = total
                elif c_type == "INSTRUCTION":
                    metrics["instruction_coverage"] = round(pct, 2)
                elif c_type == "METHOD":
                    metrics["method_coverage"] = round(pct, 2)
                elif c_type == "CLASS":
                    metrics["class_coverage"] = round(pct, 2)

            return metrics
        except Exception:
            return self._parse_jacoco_html()

    def _parse_jacoco_html(self) -> Optional[Dict[str, float]]:
        """Fallback parser if jacoco.xml is missing but index.html exists."""
        html_file = self.project_dir / "target" / "site" / "jacoco" / "index.html"
        if not html_file.is_file():
            return None

        try:
            content = html_file.read_text(encoding="utf-8", errors="replace")
            # Look for <tfoot> total row: e.g. <td>Total</td> ... <td class="ctr2">85%</td>
            match = re.search(r'<tfoot>.*?<tr>\s*<td>Total</td>(.*?)</tr>\s*</tfoot>', content, re.DOTALL | re.IGNORECASE)
            if match:
                row_content = match.group(1)
                percentages = re.findall(r'>(\d+)%<', row_content)
                if percentages:
                    # Usually first is instruction or line coverage
                    line_pct = float(percentages[0])
                    branch_pct = float(percentages[1]) if len(percentages) > 1 else line_pct
                    return {
                        "line_coverage": line_pct,
                        "branch_coverage": branch_pct,
                        "instruction_coverage": line_pct,
                        "method_coverage": line_pct,
                        "class_coverage": line_pct,
                        "covered_lines": 0,
                        "missed_lines": 0,
                        "total_lines": 0,
                    }
        except Exception:
            pass
        return None

    def extract_error_summary(self, maven_output: str, max_lines: int = 40) -> str:
        """
        Extracts compilation errors and JUnit failure stack traces from Maven output.
        Returns a concise error block suitable for AI auto-repair prompts.
        """
        lines = maven_output.splitlines()
        error_lines = []
        capture = False
        capture_count = 0

        for line in lines:
            # Check for compiler error markers
            if "[ERROR] /" in line or "[ERROR] C:" in line or "[ERROR] COMPILATION ERROR" in line:
                error_lines.append(line.strip())
            elif "FAILURE!" in line or "Failures:" in line or "Errors:" in line:
                capture = True
                error_lines.append(line.strip())
            elif capture:
                if line.startswith("[INFO]") or line.startswith("[ERROR] ->"):
                    capture = False
                else:
                    error_lines.append(line.strip())
                    capture_count += 1
                    if capture_count >= max_lines:
                        capture = False

        if not error_lines:
            # Fallback: grab all [ERROR] lines
            error_lines = [l.strip() for l in lines if l.startswith("[ERROR]")][:max_lines]

        if not error_lines:
            # Grab last 25 lines of output
            error_lines = lines[-25:]

        return "\n".join(error_lines)
