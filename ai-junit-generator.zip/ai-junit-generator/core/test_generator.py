"""
Orchestrator and auto-repair loop for AI-Driven Automated JUnit Test Generator.
Coordinates:
- Project validation (pom.xml, .git)
- Scope identification (Full Codebase vs Developer Changes)
- Baseline coverage assessment
- Test generation driven by SKILL.md
- Strict guardrails (ZERO source code modification under src/main/)
- Maven verification & Auto-Repair Loop (up to max_retries attempts)
- Post-generation coverage calculation
"""

import os
import re
from pathlib import Path
from typing import List, Dict, Any, Optional, Generator, Tuple

from config import (
    GeneratorConfig,
    ALLOWED_TEST_DIR_REL,
    PROTECTED_SRC_DIR_REL,
)
from core.git_handler import GitHandler
from core.maven_runner import MavenRunner
from core.llm_client import LLMClient


class TestGeneratorOrchestrator:
    def __init__(self, config: GeneratorConfig):
        self.config = config
        self.project_dir = Path(config.project_path).resolve()
        self.git = GitHandler(str(self.project_dir))
        self.maven = MavenRunner(str(self.project_dir), timeout_sec=config.maven_timeout)
        self.llm = LLMClient(config)

    def validate_project(self) -> Tuple[bool, str]:
        """
        Validates that the project path exists, contains pom.xml, and is a git repository.
        """
        if not self.project_dir.exists():
            return False, f"Directory does not exist: {self.project_dir}"
        if not (self.project_dir / "pom.xml").is_file():
            return False, f"pom.xml not found at project root: {self.project_dir}"
        if not self.git.is_git_repository():
            return False, f"Not a valid Git repository: .git directory not found in {self.project_dir}"
        return True, "Project directory is valid."

    def discover_all_source_classes(self) -> List[Dict[str, Any]]:
        """
        Full Codebase Mode:
        Finds all target concrete Java classes inside src/main/java/.
        """
        src_main_java = self.project_dir / "src" / "main" / "java"
        if not src_main_java.exists():
            return []

        classes = []
        for java_file in src_main_java.rglob("*.java"):
            # Skip package-info and module-info
            if java_file.name in ("package-info.java", "module-info.java"):
                continue

            try:
                content = java_file.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            # Skip pure interfaces without default methods, or annotations
            if re.search(r"\bpublic\s+@?interface\b", content) and "default " not in content:
                continue

            # Extract package name
            pkg_match = re.search(r"^\s*package\s+([\w\.]+);", content, re.MULTILINE)
            package_name = pkg_match.group(1) if pkg_match else ""

            rel_path = java_file.relative_to(self.project_dir).as_posix()
            classes.append({
                "rel_path": rel_path,
                "abs_path": str(java_file),
                "file_name": java_file.name,
                "class_name": java_file.stem,
                "package_name": package_name,
                "source_code": content,
                "diff": None,
                "change_type": "full_codebase",
            })

        return sorted(classes, key=lambda c: c["rel_path"])

    def discover_developer_change_classes(self) -> List[Dict[str, Any]]:
        """
        Developer Changes Mode:
        Identifies modified/added .java files using Git diffs.
        """
        changes = self.git.get_developer_changes(base_branch=self.config.base_branch)
        target_classes = []

        for item in changes:
            abs_p = Path(item["abs_path"])
            if not abs_p.is_file():
                continue

            try:
                content = abs_p.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            pkg_match = re.search(r"^\s*package\s+([\w\.]+);", content, re.MULTILINE)
            package_name = pkg_match.group(1) if pkg_match else ""

            target_classes.append({
                "rel_path": item["rel_path"],
                "abs_path": item["abs_path"],
                "file_name": item["file_name"],
                "class_name": item["class_name"],
                "package_name": package_name,
                "source_code": content,
                "diff": item["diff"],
                "change_type": item["change_type"],
            })

        return target_classes

    def get_test_file_path(self, target_class: Dict[str, Any]) -> Path:
        """
        Determines destination test file path inside src/test/java/.
        STRICT GUARDRAIL: Guarantees path is inside src/test/java.
        """
        package_name = target_class.get("package_name", "")
        class_name = target_class.get("class_name", "")
        test_class_name = f"{class_name}Test.java"

        pkg_dir = package_name.replace(".", "/")
        test_path = self.project_dir / "src" / "test" / "java" / pkg_dir / test_class_name
        return test_path.resolve()

    def _assert_safe_write_path(self, file_path: Path):
        """
        STRICT GUARDRAIL:
        Verifies that writing to this file path is strictly permitted (under src/test/java).
        Raises PermissionError if any attempt is made to write to src/main or outside.
        """
        allowed_root = (self.project_dir / "src" / "test" / "java").resolve()
        resolved_target = file_path.resolve()

        if not str(resolved_target).startswith(str(allowed_root)):
            raise PermissionError(
                f"STRICT SECURITY GUARDRAIL VIOLATION: Attempted write to '{resolved_target}'. "
                f"Tool is strictly restricted to writing inside '{allowed_root}'."
            )

    def write_test_file(self, target_class: Dict[str, Any], test_code: str) -> Path:
        """Writes the generated test file safely inside src/test/java."""
        test_file_path = self.get_test_file_path(target_class)
        self._assert_safe_write_path(test_file_path)

        test_file_path.parent.mkdir(parents=True, exist_ok=True)
        test_file_path.write_text(test_code, encoding="utf-8")
        return test_file_path

    def run_generation_pipeline(self) -> Generator[Dict[str, Any], None, Dict[str, Any]]:
        """
        Main orchestration pipeline yielding real-time progress events for the UI.
        Yields dictionaries with:
        {
            "stage": str,
            "message": str,
            "progress": float (0.0 to 1.0),
            "status": "info" | "warning" | "error" | "success",
            "data": Any
        }
        """
        # Step 1: Validation
        yield {
            "stage": "validation",
            "message": "Validating project path, pom.xml, and Git repository...",
            "progress": 0.05,
            "status": "info",
        }

        is_valid, val_msg = self.validate_project()
        if not is_valid:
            yield {
                "stage": "validation",
                "message": f"Validation Error: {val_msg}",
                "progress": 0.05,
                "status": "error",
            }
            return {"success": False, "error": val_msg}

        # Step 2: Baseline Git snapshot of src/main/
        baseline_git_status = self.git.get_src_main_status()

        # Step 3: Scope Identification
        yield {
            "stage": "scope",
            "message": f"Identifying target classes (Mode: {self.config.mode})...",
            "progress": 0.10,
            "status": "info",
        }

        if self.config.mode == "changes":
            target_classes = self.discover_developer_change_classes()
            if not target_classes:
                yield {
                    "stage": "scope",
                    "message": "No uncommitted or branch-committed Java changes found in src/main/java/. Falling back to Full Codebase Mode.",
                    "progress": 0.12,
                    "status": "warning",
                }
                target_classes = self.discover_all_source_classes()
        else:
            target_classes = self.discover_all_source_classes()

        if not target_classes:
            msg = "No eligible Java classes found under src/main/java/ to generate tests for."
            yield {
                "stage": "scope",
                "message": msg,
                "progress": 0.15,
                "status": "error",
            }
            return {"success": False, "error": msg}

        yield {
            "stage": "scope",
            "message": f"Found {len(target_classes)} target Java class(es) to analyze.",
            "progress": 0.15,
            "status": "success",
            "data": [c["class_name"] for c in target_classes],
        }

        # Step 4: Baseline Coverage Assessment
        yield {
            "stage": "baseline_coverage",
            "message": "Running Maven baseline coverage check with JaCoCo...",
            "progress": 0.20,
            "status": "info",
        }

        retcode, baseline_output, baseline_metrics = self.maven.run_baseline_coverage()
        current_coverage = baseline_metrics.get("line_coverage", 0.0) if baseline_metrics else 0.0

        yield {
            "stage": "baseline_coverage",
            "message": f"Baseline code coverage assessed: {current_coverage:.1f}%",
            "progress": 0.30,
            "status": "success",
            "data": {
                "current_coverage": current_coverage,
                "metrics": baseline_metrics or {},
                "target_coverage": self.config.target_coverage,
            },
        }

        # Step 5: Test Generation & Auto-Repair Loop for Each Class
        generated_results = []
        total_classes = len(target_classes)

        for idx, target in enumerate(target_classes):
            class_name = target["class_name"]
            pkg_name = target["package_name"]
            base_progress = 0.30 + ((idx / total_classes) * 0.45)

            yield {
                "stage": "generating",
                "message": f"[{idx+1}/{total_classes}] Generating JUnit 5 tests for {class_name}.java...",
                "progress": round(base_progress, 2),
                "status": "info",
                "target_class": class_name,
            }

            # Check if an existing test exists
            test_file_path = self.get_test_file_path(target)
            existing_test = ""
            if test_file_path.is_file():
                try:
                    existing_test = test_file_path.read_text(encoding="utf-8", errors="replace")
                except Exception:
                    pass

            # Initial Generation via LLM
            try:
                test_code = self.llm.generate_junit_test(
                    source_code=target["source_code"],
                    class_name=class_name,
                    package_name=pkg_name,
                    diff_context=target.get("diff"),
                    existing_test=existing_test if existing_test else None,
                )
            except Exception as e:
                yield {
                    "stage": "generating",
                    "message": f"Failed to generate tests for {class_name}: {str(e)}",
                    "progress": round(base_progress, 2),
                    "status": "error",
                }
                continue

            # Write test file (strictly under src/test/java)
            self.write_test_file(target, test_code)

            # Auto-Repair Loop (up to max_retries)
            repair_attempt = 0
            repair_history = []
            test_passed = False

            while repair_attempt <= self.config.max_retries:
                yield {
                    "stage": "verifying",
                    "message": f"Verifying {class_name}Test (Attempt {repair_attempt + 1}/{self.config.max_retries + 1})...",
                    "progress": round(base_progress + 0.02, 2),
                    "status": "info",
                }

                # Run fast single test verification
                test_retcode, test_output = self.maven.run_single_test_class(f"{class_name}Test")

                if test_retcode == 0:
                    test_passed = True
                    yield {
                        "stage": "verifying",
                        "message": f"Verification passed for {class_name}Test!",
                        "progress": round(base_progress + 0.04, 2),
                        "status": "success",
                    }
                    break

                repair_attempt += 1
                if repair_attempt > self.config.max_retries:
                    yield {
                        "stage": "repair",
                        "message": f"Maximum retries ({self.config.max_retries}) reached for {class_name}Test. Retaining latest generated version.",
                        "progress": round(base_progress + 0.04, 2),
                        "status": "warning",
                    }
                    break

                error_summary = self.maven.extract_error_summary(test_output)
                repair_history.append({"attempt": repair_attempt, "error": error_summary})

                yield {
                    "stage": "repair",
                    "message": f"Build failed for {class_name}Test. Running AI Auto-Repair cycle (Attempt {repair_attempt}/{self.config.max_retries})...",
                    "progress": round(base_progress + 0.03, 2),
                    "status": "warning",
                    "error_summary": error_summary,
                }

                try:
                    repaired_code = self.llm.repair_junit_test(
                        source_code=target["source_code"],
                        class_name=class_name,
                        package_name=pkg_name,
                        failing_test_code=test_code,
                        error_logs=error_summary,
                        retry_count=repair_attempt,
                    )
                    test_code = repaired_code
                    self.write_test_file(target, test_code)
                except Exception as e:
                    yield {
                        "stage": "repair",
                        "message": f"AI repair failed for {class_name}Test: {str(e)}",
                        "progress": round(base_progress + 0.04, 2),
                        "status": "error",
                    }
                    break

            generated_results.append({
                "class_name": class_name,
                "test_file": str(test_file_path),
                "passed": test_passed,
                "repair_attempts": repair_attempt,
                "code": test_code,
            })

        # Step 6: Final Verification & Clean Test Suite Execution
        yield {
            "stage": "final_verification",
            "message": "Executing full `mvn clean test` and generating final JaCoCo report...",
            "progress": 0.85,
            "status": "info",
        }

        final_retcode, final_output, final_metrics = self.maven.run_clean_test(with_jacoco=True)
        final_coverage = final_metrics.get("line_coverage", 0.0) if final_metrics else current_coverage

        # Step 7: STRICT GUARDRAIL - Assert Source Integrity
        yield {
            "stage": "integrity_check",
            "message": "Verifying strict guardrail: Zero source code modification under src/main/...",
            "progress": 0.95,
            "status": "info",
        }

        intact, integrity_msg = self.git.verify_source_integrity(baseline_git_status)
        if not intact:
            yield {
                "stage": "integrity_check",
                "message": f"GUARDRAIL BREACH: {integrity_msg}",
                "progress": 0.95,
                "status": "error",
            }
            return {
                "success": False,
                "error": integrity_msg,
                "final_coverage": final_coverage,
                "current_coverage": current_coverage,
            }

        # Step 8: Done!
        summary = {
            "success": (final_retcode == 0),
            "current_coverage": current_coverage,
            "target_coverage": self.config.target_coverage,
            "final_coverage": final_coverage,
            "coverage_metrics": final_metrics or {},
            "generated_classes": generated_results,
            "source_integrity": integrity_msg,
            "build_exit_code": final_retcode,
        }

        yield {
            "stage": "complete",
            "message": f"Process completed. Post-Tool Coverage: {final_coverage:.1f}% (Baseline: {current_coverage:.1f}% | Target: {self.config.target_coverage:.1f}%)",
            "progress": 1.0,
            "status": "success" if final_retcode == 0 else "warning",
            "data": summary,
        }

        return summary
