"""
Core modules for AI-Driven Automated JUnit Test Generator.
"""
