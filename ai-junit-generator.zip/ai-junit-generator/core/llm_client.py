"""
LLM Client integration module.
Handles:
- Loading and injecting SKILL.md guidelines
- Multi-provider support (Gemini, OpenAI, Anthropic, Ollama, OpenAI-Compatible)
- Offline Mock / Dry-Run generation fallback
- Prompt construction for new JUnit 5 tests
- Auto-repair prompt construction for fixing compiler and test failures
- Code extraction and sanitization
"""

import os
import re
import json
from pathlib import Path
from typing import Optional, Dict, Any, List
import requests

from config import (
    DEFAULT_SKILL_PATH,
    SUPPORTED_PROVIDERS,
    GeneratorConfig,
)


class LLMClient:
    def __init__(self, config: GeneratorConfig):
        self.config = config
        self.skill_content = self._load_skill_file()

    def _load_skill_file(self) -> str:
        """Loads SKILL.md guidelines from configured path."""
        p = Path(self.config.skill_file_path)
        if not p.is_file():
            p = DEFAULT_SKILL_PATH
        if p.is_file():
            try:
                return p.read_text(encoding="utf-8", errors="replace")
            except Exception:
                pass
        return "Generate robust, maintainable JUnit 5 unit tests with Mockito following AAA pattern."

    def _clean_java_code(self, raw_text: str) -> str:
        """Strips markdown code blocks, preamble, and conversational commentary."""
        text = raw_text.strip()
        # Look for ```java ... ``` block
        pattern = r"```(?:java)?\s*\n([\s\S]*?)```"
        matches = re.findall(pattern, text, re.IGNORECASE)
        if matches:
            # Pick the largest block which is almost certainly the test class
            code = max(matches, key=len).strip()
            return code
        
        # If no markdown block, check if it starts with package/import
        lines = text.splitlines()
        first_code_idx = 0
        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith("package ") or stripped.startswith("import ") or stripped.startswith("/*") or stripped.startswith("//") or stripped.startswith("@"):
                first_code_idx = i
                break
        
        clean = "\n".join(lines[first_code_idx:]).strip()
        # Remove trailing markdown if any
        if clean.endswith("```"):
            clean = clean[:-3].strip()
        return clean

    def generate_junit_test(
        self,
        source_code: str,
        class_name: str,
        package_name: str,
        diff_context: Optional[str] = None,
        existing_test: Optional[str] = None,
    ) -> str:
        """
        Generates a complete JUnit 5 test class for the given target Java source.
        """
        system_prompt = (
            "You are an expert Java / Spring Boot QA Automation engineer.\n"
            "Your task is to write a complete, standalone, production-grade JUnit 5 test class "
            "for the provided Java class, strictly following the SKILL.md guidelines.\n\n"
            f"=== SKILL.MD GUIDELINES ===\n{self.skill_content}\n"
            "===========================\n"
            "STRICT RULES:\n"
            "1. Output ONLY valid compilable Java code.\n"
            "2. Do NOT enclose in explanations or conversational markdown; code only.\n"
            f"3. Class name MUST be `{class_name}Test` in package `{package_name}`.\n"
            "4. Ensure ALL required imports are included (JUnit 5, Mockito, Assertions, target class).\n"
            "5. Aim for maximum branch and line coverage (>90%)."
        )

        user_prompt = f"TARGET CLASS TO TEST:\nPackage: {package_name}\nClass: {class_name}\n\n```java\n{source_code}\n```\n"

        if diff_context:
            user_prompt += (
                f"\nNOTE: The developer has recently modified this class. Focus especially on "
                f"covering these modified/added lines and methods:\n```diff\n{diff_context}\n```\n"
            )

        if existing_test:
            user_prompt += (
                f"\nEXISTING TEST CLASS (expand, enhance, or rewrite to reach target coverage):\n"
                f"```java\n{existing_test}\n```\n"
            )

        user_prompt += f"\nPlease generate the complete `{class_name}Test.java` class now."

        raw_code = self._call_llm(system_prompt, user_prompt, fallback_type="generate", 
                                  context={"source": source_code, "class_name": class_name, "package_name": package_name})
        return self._clean_java_code(raw_code)

    def repair_junit_test(
        self,
        source_code: str,
        class_name: str,
        package_name: str,
        failing_test_code: str,
        error_logs: str,
        retry_count: int,
    ) -> str:
        """
        Auto-repair cycle: Asks the LLM to analyze the compilation or test failure
        and provide a fixed version of the test class.
        """
        system_prompt = (
            "You are an expert Java / Spring Boot debugger and QA engineer.\n"
            "The generated JUnit 5 test failed compilation or execution during `mvn clean test`.\n"
            "Your task is to FIX the test class so that it compiles and passes cleanly.\n\n"
            f"=== SKILL.MD GUIDELINES ===\n{self.skill_content}\n"
            "===========================\n"
            "STRICT REPAIR INSTRUCTIONS:\n"
            "1. Analyze the exact compiler or assertion error in the logs.\n"
            "2. Fix missing imports, improper Mockito matchers, wrong method signatures, or failing assertions.\n"
            "3. Output the COMPLETE corrected Java test class with all imports.\n"
            "4. Output ONLY Java code without preamble."
        )

        user_prompt = (
            f"TARGET CLASS BEING TESTED:\n```java\n{source_code}\n```\n\n"
            f"FAILING TEST CLASS (Attempt {retry_count}):\n```java\n{failing_test_code}\n```\n\n"
            f"MAVEN ERROR LOGS & STACK TRACE:\n```text\n{error_logs}\n```\n\n"
            f"Please output the complete, corrected `{class_name}Test.java` class."
        )

        raw_code = self._call_llm(system_prompt, user_prompt, fallback_type="repair", 
                                  context={"source": source_code, "class_name": class_name, "package_name": package_name, "failing_test": failing_test_code, "errors": error_logs})
        return self._clean_java_code(raw_code)

    def _call_llm(self, system_prompt: str, user_prompt: str, fallback_type: str, context: Dict[str, Any]) -> str:
        """Dispatches the prompt to the configured LLM provider."""
        provider = self.config.llm_provider
        api_key = self.config.get_api_key()

        if provider == "dry_run" or not api_key and provider not in ("ollama", "dry_run"):
            # If no API key or dry_run, return intelligent local mock JUnit generator
            return self._generate_mock_test(context)

        try:
            if provider == "gemini":
                return self._call_gemini(system_prompt, user_prompt, api_key)
            elif provider == "openai":
                return self._call_openai(system_prompt, user_prompt, api_key)
            elif provider == "anthropic":
                return self._call_anthropic(system_prompt, user_prompt, api_key)
            elif provider == "ollama":
                return self._call_ollama(system_prompt, user_prompt)
            elif provider == "openai_compatible":
                return self._call_openai_compatible(system_prompt, user_prompt, api_key)
            else:
                return self._generate_mock_test(context)
        except Exception as e:
            # If API call fails, raise informative error or fallback
            raise RuntimeError(f"LLM API call failed for provider '{provider}': {str(e)}")

    def _call_gemini(self, system_prompt: str, user_prompt: str, api_key: str) -> str:
        """Direct REST call to Google Gemini API."""
        model = self.config.llm_model or "gemini-2.5-flash"
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
        
        payload = {
            "system_instruction": {
                "parts": [{"text": system_prompt}]
            },
            "contents": [
                {
                    "role": "user",
                    "parts": [{"text": user_prompt}]
                }
            ],
            "generationConfig": {
                "temperature": 0.2,
                "maxOutputTokens": 8192,
            }
        }

        resp = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=120)
        if resp.status_code != 200:
            raise RuntimeError(f"Gemini API returned status {resp.status_code}: {resp.text}")

        data = resp.json()
        candidates = data.get("candidates", [])
        if candidates and "content" in candidates[0]:
            parts = candidates[0]["content"].get("parts", [])
            if parts:
                return parts[0].get("text", "")
        raise RuntimeError("No text returned in Gemini response.")

    def _call_openai(self, system_prompt: str, user_prompt: str, api_key: str) -> str:
        """Call OpenAI API."""
        model = self.config.llm_model or "gpt-4o"
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.2,
        }
        resp = requests.post(url, json=payload, headers=headers, timeout=120)
        if resp.status_code != 200:
            raise RuntimeError(f"OpenAI API returned status {resp.status_code}: {resp.text}")
        data = resp.json()
        return data["choices"][0]["message"]["content"]

    def _call_anthropic(self, system_prompt: str, user_prompt: str, api_key: str) -> str:
        """Call Anthropic API."""
        model = self.config.llm_model or "claude-3-7-sonnet-20250219"
        url = "https://api.anthropic.com/v1/messages"
        headers = {
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }
        payload = {
            "model": model,
            "system": system_prompt,
            "messages": [
                {"role": "user", "content": user_prompt}
            ],
            "max_tokens": 4096,
            "temperature": 0.2,
        }
        resp = requests.post(url, json=payload, headers=headers, timeout=120)
        if resp.status_code != 200:
            raise RuntimeError(f"Anthropic API returned status {resp.status_code}: {resp.text}")
        data = resp.json()
        return data["content"][0]["text"]

    def _call_ollama(self, system_prompt: str, user_prompt: str) -> str:
        """Call local Ollama API."""
        endpoint = self.config.custom_endpoint or "http://localhost:11434"
        url = f"{endpoint.rstrip('/')}/api/chat"
        model = self.config.llm_model or "qwen2.5-coder:latest"
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "stream": False,
            "options": {"temperature": 0.2}
        }
        resp = requests.post(url, json=payload, timeout=180)
        if resp.status_code != 200:
            raise RuntimeError(f"Ollama returned status {resp.status_code}: {resp.text}")
        data = resp.json()
        return data["message"]["content"]

    def _call_openai_compatible(self, system_prompt: str, user_prompt: str, api_key: str) -> str:
        """Call custom OpenAI compatible endpoint."""
        endpoint = self.config.custom_endpoint or "https://api.groq.com/openai/v1"
        url = f"{endpoint.rstrip('/')}/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}" if api_key else "",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.config.llm_model or "llama-3.3-70b-versatile",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.2,
        }
        resp = requests.post(url, json=payload, headers=headers, timeout=120)
        if resp.status_code != 200:
            raise RuntimeError(f"OpenAI-Compatible endpoint returned status {resp.status_code}: {resp.text}")
        data = resp.json()
        return data["choices"][0]["message"]["content"]

    def _generate_mock_test(self, context: Dict[str, Any]) -> str:
        """
        Intelligent local fallback generator.
        Parses methods and fields from target Java class to generate a valid, compilable JUnit 5 test class.
        Used for dry-run testing or when running without external API key.
        """
        source = context.get("source", "")
        class_name = context.get("class_name", "TargetClass")
        package_name = context.get("package_name", "com.example")
        failing_test = context.get("failing_test", "")
        errors = context.get("errors", "")

        # If it's a repair request on an existing test
        if failing_test and errors:
            # If missing imports or annotations, add them
            repaired = failing_test
            if "MockitoExtension" in errors and "import org.mockito.junit.jupiter.MockitoExtension;" not in repaired:
                repaired = repaired.replace("import org.junit.jupiter.api.Test;", 
                                            "import org.junit.jupiter.api.Test;\nimport org.mockito.junit.jupiter.MockitoExtension;\nimport org.junit.jupiter.api.extension.ExtendWith;")
            return repaired

        # Extract public methods from source
        method_pattern = r"(?:public|protected)\s+(?:static\s+)?([\w<>\[\],\s]+)\s+(\w+)\s*\(([^)]*)\)"
        methods = re.findall(method_pattern, source)
        
        # Check if Spring annotations are present
        is_controller = "@RestController" in source or "@Controller" in source
        is_service = "@Service" in source or "@Component" in source
        
        test_methods_code = []
        for return_type, m_name, params in methods:
            if m_name in (class_name, "equals", "hashCode", "toString"):
                continue
            
            clean_ret = return_type.strip()
            test_m_code = f"""
    @Test
    @DisplayName("Should test {m_name}() successfully")
    void {m_name}_success() {{
        // Arrange
        // Act
        // Assert
        assertTrue(true, "Auto-generated test execution for {m_name}");
    }}

    @Test
    @DisplayName("Should test {m_name}() edge and boundary conditions")
    void {m_name}_boundaryConditions() {{
        // Arrange & Act & Assert
        assertDoesNotThrow(() -> {{
            // Test null or boundary execution
        }});
    }}
"""
            test_methods_code.append(test_m_code)

        if not test_methods_code:
            test_methods_code.append(f"""
    @Test
    @DisplayName("Should verify {class_name} instantiation")
    void contextLoads() {{
        assertNotNull(target, "{class_name} should not be null");
    }}
""")

        all_tests_str = "\n".join(test_methods_code)

        code = f"""package {package_name};

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * JUnit 5 test class for {class_name}.
 * Generated automatically by AI-Driven JUnit Test Generator.
 */
@ExtendWith(MockitoExtension.class)
class {class_name}Test {{

    @InjectMocks
    private {class_name} target;

    @BeforeEach
    void setUp() {{
        // Setup mocks and preconditions if needed
    }}
{all_tests_str}
}}
"""
        return code
