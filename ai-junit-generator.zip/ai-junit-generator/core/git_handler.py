"""
Git version control integration handler.
Handles:
- Validation of .git repository
- Uncommitted changes detection (git status, git diff)
- Committed changes detection relative to a base branch
- Target file diff extraction
- Source integrity verification (verifying src/main is strictly untouched)
"""

import os
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple


class GitHandler:
    def __init__(self, project_dir: str):
        self.project_dir = Path(project_dir).resolve()

    def _run_git(self, args: List[str], check: bool = False) -> subprocess.CompletedProcess:
        """Executes a git command in the project directory."""
        cmd = ["git"] + args
        try:
            return subprocess.run(
                cmd,
                cwd=str(self.project_dir),
                capture_output=True,
                text=True,
                check=check,
                encoding="utf-8",
                errors="replace",
            )
        except FileNotFoundError:
            raise RuntimeError("Git executable not found in system PATH.")

    def is_git_repository(self) -> bool:
        """Checks if the project path is a valid git repository."""
        # Check for .git directory directly or via rev-parse
        git_dir = self.project_dir / ".git"
        if git_dir.exists():
            return True
        proc = self._run_git(["rev-parse", "--is-inside-work-tree"])
        return proc.returncode == 0 and "true" in proc.stdout.strip().lower()

    def get_current_branch(self) -> str:
        """Returns the current checked out git branch name."""
        proc = self._run_git(["rev-parse", "--abbrev-ref", "HEAD"])
        if proc.returncode == 0:
            branch = proc.stdout.strip()
            if branch:
                return branch
        return "HEAD"

    def get_available_branches(self) -> List[str]:
        """Lists local and remote branches."""
        proc = self._run_git(["branch", "-a"])
        branches = []
        if proc.returncode == 0:
            for line in proc.stdout.splitlines():
                clean = line.strip().lstrip("* ").strip()
                if clean and "->" not in clean:
                    if clean.startswith("remotes/origin/"):
                        clean = clean[len("remotes/origin/"):]
                    if clean not in branches:
                        branches.append(clean)
        if not branches:
            branches = ["main", "master"]
        return branches

    def get_uncommitted_java_files(self) -> List[Dict[str, Any]]:
        """
        Detects uncommitted modified, added, or untracked .java files under src/main/java/.
        """
        results = []
        # Run porcelain status
        proc = self._run_git(["status", "--porcelain", "src/main/java/"])
        if proc.returncode != 0:
            return results

        seen_paths = set()
        for line in proc.stdout.splitlines():
            line = line.rstrip()
            if len(line) < 4:
                continue
            status_code = line[:2].strip()
            filepath_str = line[3:].strip().strip('"')
            
            # If renamed, take the target path
            if " -> " in filepath_str:
                filepath_str = filepath_str.split(" -> ")[1].strip().strip('"')

            rel_path = Path(filepath_str)
            if not rel_path.name.endswith(".java"):
                continue

            # Standardize path
            norm_rel = rel_path.as_posix()
            if norm_rel in seen_paths:
                continue
            seen_paths.add(norm_rel)

            abs_path = self.project_dir / rel_path
            diff_text = self.get_file_diff(norm_rel)

            change_type = "uncommitted_modified"
            if "?" in status_code:
                change_type = "uncommitted_untracked"
            elif "A" in status_code:
                change_type = "uncommitted_added"

            results.append({
                "rel_path": norm_rel,
                "abs_path": str(abs_path),
                "file_name": rel_path.name,
                "class_name": rel_path.stem,
                "change_type": change_type,
                "diff": diff_text,
            })
        return results

    def get_branch_diff_java_files(self, base_branch: str = "main") -> List[Dict[str, Any]]:
        """
        Detects committed .java files under src/main/java/ that differ from the base branch.
        """
        results = []
        # Try three dots (merge-base) or two dots
        diff_args = [["diff", "--name-only", f"{base_branch}...HEAD", "--", "src/main/java/"],
                     ["diff", "--name-only", f"{base_branch}", "--", "src/main/java/"],
                     ["diff", "--name-only", f"origin/{base_branch}...HEAD", "--", "src/main/java/"]]

        stdout = ""
        used_target = ""
        for args in diff_args:
            proc = self._run_git(args)
            if proc.returncode == 0:
                stdout = proc.stdout
                used_target = args[2]
                break

        if not stdout:
            return results

        for line in stdout.splitlines():
            norm_rel = line.strip().strip('"').replace("\\", "/")
            if not norm_rel.endswith(".java") or not norm_rel.startswith("src/main/java/"):
                continue

            abs_path = self.project_dir / Path(norm_rel)
            if not abs_path.exists():
                # Deleted file in branch
                continue

            diff_text = self.get_branch_file_diff(norm_rel, used_target)
            results.append({
                "rel_path": norm_rel,
                "abs_path": str(abs_path),
                "file_name": Path(norm_rel).name,
                "class_name": Path(norm_rel).stem,
                "change_type": "branch_committed",
                "diff": diff_text,
            })
        return results

    def get_file_diff(self, rel_path: str) -> str:
        """Gets uncommitted diff for a specific file (staged or unstaged)."""
        # Try unstaged diff
        proc = self._run_git(["diff", "--", rel_path])
        diff = proc.stdout.strip()
        if not diff:
            # Try staged diff
            proc_cached = self._run_git(["diff", "--cached", "--", rel_path])
            diff = proc_cached.stdout.strip()
        if not diff:
            # For untracked files, read entire content as addition
            abs_p = self.project_dir / rel_path
            if abs_p.exists():
                try:
                    content = abs_p.read_text(encoding="utf-8", errors="replace")
                    return f"--- /dev/null\n+++ {rel_path}\n@@ -0,0 +1,{len(content.splitlines())} @@\n" + \
                           "\n".join("+" + l for l in content.splitlines()[:100])
                except Exception:
                    pass
        return diff

    def get_branch_file_diff(self, rel_path: str, diff_target: str) -> str:
        """Gets branch diff for a specific file relative to base branch."""
        proc = self._run_git(["diff", diff_target, "--", rel_path])
        if proc.returncode == 0:
            return proc.stdout.strip()
        return ""

    def get_developer_changes(self, base_branch: str = "main") -> List[Dict[str, Any]]:
        """
        Combines uncommitted changes and committed branch changes for Developer Changes Mode.
        Deduplicates by relative path.
        """
        uncommitted = self.get_uncommitted_java_files()
        branch_diffs = self.get_branch_diff_java_files(base_branch)

        combined: Dict[str, Dict[str, Any]] = {}
        # Uncommitted take priority because they represent current active dev work
        for item in branch_diffs:
            combined[item["rel_path"]] = item
        for item in uncommitted:
            combined[item["rel_path"]] = item

        return list(combined.values())

    def get_src_main_status(self) -> str:
        """Captures status hash / porcelain output of src/main/ to verify zero modification."""
        proc = self._run_git(["status", "--porcelain", "src/main/"])
        if proc.returncode == 0:
            return proc.stdout.strip()
        return ""

    def verify_source_integrity(self, baseline_status: Optional[str] = None) -> Tuple[bool, str]:
        """
        STRICT GUARDRAIL:
        Verifies that src/main/ was not modified in any way by the tool.
        Returns (is_intact, message).
        """
        current_status = self.get_src_main_status()
        if baseline_status is None:
            # If no baseline provided, ensure src/main/ has zero uncommitted changes
            if current_status:
                return False, f"src/main/ has uncommitted modifications: {current_status}"
            return True, "src/main/ is completely clean and untouched."
        
        if current_status != baseline_status:
            return False, f"Source code modified! Baseline:\n{baseline_status}\nCurrent:\n{current_status}"
        return True, "Strict Rule Verified: Zero source code modification under src/main/."
