"""
Configuration and default settings for AI-Driven Automated JUnit Test Generator.
"""

import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, Any, Optional

try:
    from dotenv import load_dotenv
    # Load .env if present in project or tool root
    load_dotenv()
except ImportError:
    pass

# Path constants
TOOL_ROOT = Path(__file__).resolve().parent
DEFAULT_SKILL_PATH = TOOL_ROOT / "SKILL.md"

# Code coverage defaults
DEFAULT_TARGET_COVERAGE: float = 90.0
DEFAULT_MAX_REPAIR_RETRIES: int = 3
DEFAULT_MAVEN_TIMEOUT_SEC: int = 240

# JaCoCo Maven Plugin Goals (explicit plugin invocation avoids modifying pom.xml)
JACOCO_PLUGIN_VERSION = "0.8.11"
JACOCO_PREPARE_AGENT = f"org.jacoco:jacoco-maven-plugin:{JACOCO_PLUGIN_VERSION}:prepare-agent"
JACOCO_REPORT = f"org.jacoco:jacoco-maven-plugin:{JACOCO_PLUGIN_VERSION}:report"

# Supported LLM Providers and default models
SUPPORTED_PROVIDERS = {
    "gemini": {
        "name": "Google Gemini",
        "default_model": "gemini-2.5-flash",
        "models": ["gemini-2.5-flash", "gemini-2.5-pro", "gemini-1.5-flash", "gemini-1.5-pro"],
        "env_var": "GEMINI_API_KEY",
        "api_base": "https://generativelanguage.googleapis.com/v1beta",
    },
    "openai": {
        "name": "OpenAI",
        "default_model": "gpt-4o",
        "models": ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "o3-mini"],
        "env_var": "OPENAI_API_KEY",
        "api_base": "https://api.openai.com/v1",
    },
    "anthropic": {
        "name": "Anthropic Claude",
        "default_model": "claude-3-7-sonnet-20250219",
        "models": ["claude-3-7-sonnet-20250219", "claude-3-5-sonnet-20241022", "claude-3-5-haiku-20241022"],
        "env_var": "ANTHROPIC_API_KEY",
        "api_base": "https://api.anthropic.com/v1",
    },
    "ollama": {
        "name": "Ollama (Local LLM)",
        "default_model": "qwen2.5-coder:latest",
        "models": ["qwen2.5-coder:latest", "llama3.1:latest", "codellama:latest", "deepseek-r1:latest"],
        "env_var": "",
        "api_base": "http://localhost:11434",
    },
    "openai_compatible": {
        "name": "Custom / OpenAI-Compatible (Groq, OpenRouter, DeepSeek, vLLM)",
        "default_model": "llama-3.3-70b-versatile",
        "models": ["llama-3.3-70b-versatile", "deepseek-chat", "custom"],
        "env_var": "CUSTOM_API_KEY",
        "api_base": "https://api.groq.com/openai/v1",
    },
    "dry_run": {
        "name": "Offline / Mock Generator (No API Key Required)",
        "default_model": "mock-junit5-generator",
        "models": ["mock-junit5-generator"],
        "env_var": "",
        "api_base": "",
    },
}

# Strict Guardrails: Only files under src/test/java can be created or modified
ALLOWED_TEST_DIR_REL = Path("src") / "test" / "java"
PROTECTED_SRC_DIR_REL = Path("src") / "main"


@dataclass
class GeneratorConfig:
    project_path: str = ""
    mode: str = "full"  # "full" or "changes"
    target_coverage: float = DEFAULT_TARGET_COVERAGE
    max_retries: int = DEFAULT_MAX_REPAIR_RETRIES
    base_branch: str = "main"
    llm_provider: str = "gemini"
    llm_model: str = "gemini-2.5-flash"
    api_key: str = ""
    custom_endpoint: str = ""
    skill_file_path: Path = DEFAULT_SKILL_PATH
    maven_timeout: int = DEFAULT_MAVEN_TIMEOUT_SEC

    def get_api_key(self) -> str:
        if self.api_key:
            return self.api_key
        prov_info = SUPPORTED_PROVIDERS.get(self.llm_provider, {})
        env_var = prov_info.get("env_var", "")
        if env_var:
            return os.getenv(env_var, "")
        return ""
